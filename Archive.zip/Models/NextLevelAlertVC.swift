//
//  NextLevelAlertVC.swift
//  Hunter
//
//  Created by Ingo Ngoyama on 7/31/18.
//  Copyright © 2018 IngoNgoyama. All rights reserved.
//

import UIKit
import AVFoundation

var AlertPlayer : AVAudioPlayer?

class NextLevelAlertVC{
	//global alert box
	static func showAlert(_ inViewController: UIViewController, title: String, message : String) {
		let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
		let action = UIAlertAction(title: "OK", style: .default, handler: nil)
		alert.addAction(action)
		inViewController.present(alert, animated: true, completion: nil) //nothing extra needed so no complettion needed
		
	
		//soundfx
		func playAlert(sound: String){
			let path = Bundle.main.path(forResource: "\(sound)", ofType: "mp3")!
			let url = URL(fileURLWithPath: path)
			do{
				AlertPlayer = try AVAudioPlayer(contentsOf: url)
                AlertPlayer?.play()
			} catch{
				print(error)
			}
		}
		playAlert(sound: "policeSiren")
	}
	
	
	
}

