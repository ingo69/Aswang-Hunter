//
//  TimersVC.swift
//  Hunter
//
//  Created by Ingo Ngoyama on 8/1/18.
//  Copyright © 2018 IngoNgoyama. All rights reserved.
//PURPOSE: GLOBAL CONTROL OF ALL TIMERS IN THIS APP

import UIKit
import Each
import ARKit
class TimersVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

	
	func setTimer(timerLabel: UILabel){
		timer.perform { () -> NextStep in
			countdown -= 1
			timerLabel.text = String(countdown)
			// timer runs out actions..
			if countdown == 0 {
				timerLabel.text = "you lose"
				
				return .stop
			}
			return .continue
		}
	}
	
	
	
	func restoreTimer(timerLabel: UILabel){
		countdown =  10
		timerLabel.text = String(countdown)
		
		
	}
	
	
	
	
	func setRoundTimer(limit: Int, kills: Int){
		roundTimer.perform { () -> NextStep in
			timeLimit -= 1
			
			// timeLimit runs out actions..
			if timeLimit == 0 {
				if kills >= 50 {
					NextLevelAlertVC.showAlert(self, title: "Well Done Hunter!", message: "Got to next level.")
					
				}else{
					NextLevelAlertVC.showAlert(self, title: "Try Again!", message: "Less than 50 kills")
				}
				
				timer.stop()
				//self.restoreTimer()														//restore timer
			
				

				timeLimit = 10															//in demo mode
				
				return .stop
			}
			return .continue
		}
	}
	
}
