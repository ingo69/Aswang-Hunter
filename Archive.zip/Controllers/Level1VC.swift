//  ViewController.swift
//  Hunter
//  Created by Ingo Ngoyama on 6/26/18.
//  Copyright © 2018 IngoNgoyama. All rights reserved.
//
//PURPOSE: CONTROLS ALL VISUAL, SOUND AND GAMING FUNCTIONS

/*NOTES:
    1)   add AR shooting
    2) X  stop over tapping monsternodes with a bool
    3)   make dblmonster func
    4)   make triple monster func
    5)   make level unlock orbs
    6)   Rig Aswang
    7)   give player 3 lives
    8)   monster attack: when time out monster advances to the origin and screen turns red and you die
 
*/

//import Foundation
import UIKit
import ARKit
import Each // a pod for a game timer
import AVFoundation

//MARK: GLOBAL VARIABLES###################
var soundPlayer : AVAudioPlayer?
var musicPlayer : AVAudioPlayer?
var weaponPlayer : AVAudioPlayer?
var roarPlayer : AVAudioPlayer?

var roundTimer = Each(1).minutes
var timeLimit = 10

var timer = Each(1).seconds
var countdown = 10
var kills = 0
var aswangExists = false

enum BitMaskCategory: Int{
    case bullet = 2
    case target = 3 // an assignable category for the eggnode
}



//******************************************************************
class Level1VC: UIViewController {
	
	@IBOutlet weak var weaponLabel: UILabel!	
	@IBOutlet weak var killsLabel: UILabel!
	@IBOutlet weak var timerLabel: UILabel!
	@IBOutlet weak var play: UIButton!
	@IBOutlet weak var sceneView: ARSCNView!
    
    var power: Float = 50
    var Target: SCNNode?

    //VIEW SET UP........
	let configuration =  ARWorldTrackingConfiguration()
	
	override var prefersStatusBarHidden: Bool{return true}
	

//MARK: VIEW LIFE CYCLE####################
	override func viewDidLoad() {
		super.viewDidLoad()
		
		if play.isEnabled == false{
			setRoundTimer()
		}

		playMusic(track: "scaryMusic1")
		
		//self.sceneView.debugOptions = [ ARSCNDebugOptions.showFeaturePoints, ARSCNDebugOptions.showWorldOrigin]
		self.sceneView.session.run(configuration)
        
        self.sceneView.autoenablesDefaultLighting = true
		
		//make view recognize taps
		let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))//mk a tpgRcgzr
		self.sceneView.addGestureRecognizer(tapGestureRecognizer)// make scene recogninze the tap
        self.sceneView.scene.physicsWorld.contactDelegate = self as? SCNPhysicsContactDelegate //for collision physics  ???
	}
	
	
//MARK: BUTTONS###################
	@IBAction func playBtn(_ sender: Any) {
		
		self.setTimer()
		self.addAswang()
		self.play.isEnabled = false
		self.playMusic(track: "scaryMusic1")
		setRoundTimer()
		playSound(sound: "growl1")
	}
    
	@IBAction func resetBtn(_ sender: Any) {
		if self.play.isEnabled == false {
			timer.stop()
			restoreTimer()
			kills = 0
			killsLabel.text = String("kills: \(kills)")
			self.play.isEnabled = true
			sceneView.scene.rootNode.enumerateChildNodes { (node, _) in
				node.removeFromParentNode()
			}
		}
	}
	
	@IBAction func multiBtn(_ sender: Any) {
		// btn functions as relocation btn if game not in playmode
		if self.play.isEnabled == true{
			self.restartSession() //relocate game
		}else{
			
			//btn functions as weapon changer when in play mode
			if weaponLabel.text == "Sword"{
				weaponLabel.text = "Assault Rifle"
			}else{
				weaponLabel.text = "Sword"
			}
		}
	}
	
    @IBAction func ShootBtn(_ sender: Any) {
        playWpnFX(fx: "rifleShot")
                
        //bullet code
       // guard let sceneview = sender.view as? ARSCNView else {return}                                                      // ???????
        guard let pointOfView = sceneView.pointOfView else {return}
        let transform = pointOfView.transform
        let orientation = SCNVector3(-transform.m31, -transform.m32, -transform.m33)
        let location = SCNVector3(transform.m41, transform.m42, transform.m43)                                                                 //!!!!!!!!bullet loc
        let position =  orientation + location

        //place the bullet in the current camera location.............................
        let bullet = SCNNode(geometry: SCNSphere(radius: 0.1))
        bullet.geometry?.firstMaterial?.diffuse.contents = UIColor.red
        bullet.position = position
        let body = SCNPhysicsBody(type: .dynamic, shape: SCNPhysicsShape(node: bullet, options: nil))
        body.isAffectedByGravity =  false
        bullet.physicsBody = body
        bullet.physicsBody?.applyForce(SCNVector3(orientation.x * power, orientation.y * power, orientation.z * power), asImpulse: true)
        bullet.physicsBody?.categoryBitMask = BitMaskCategory.bullet.rawValue
        bullet.physicsBody?.contactTestBitMask = BitMaskCategory.target.rawValue
        
       //add bullet to scene
        self.sceneView.scene.rootNode.addChildNode(bullet)

        //make bullet wait 2 seconds and then disappear after contact in a action sequence
        bullet.runAction(
            SCNAction.sequence([SCNAction.wait(duration: 2.0),
                                SCNAction.removeFromParentNode()])
        )
    }
    
    
//MARK:MAKE NODES########################
	func addAswang(){
		//make aswang...
        aswangExists = true
        
		let aswangScene = SCNScene(named: "art.scnassets/aswang.scn")
		let aswangNode = aswangScene?.rootNode.childNode(withName: "aswang", recursively: false)// false because aswang is an immediate child to the rootnode so we dont need to search every single node in the subtree
		
		// random positioning of model node..
		aswangNode?.position = SCNVector3Make(Float(randomNumbers(firstNum: -3, secondNum: 3)), Float(randomNumbers(firstNum: -2, secondNum: -2)), Float(randomNumbers(firstNum: -3, secondNum: 3)))
		
        //Add physics to  the aswangNode
          aswangNode?.physicsBody = SCNPhysicsBody.static()
        
        //add aswang to scene
        self.sceneView.scene.rootNode.addChildNode(aswangNode!)
		
        //make aswang face towards you all the time..........
		if Float((aswangNode?.position.z)!) > 0.0 {
			aswangNode?.eulerAngles = SCNVector3(0,180,0)
		}
		
		if Float((aswangNode?.position.z)!) == 0.0 && Float((aswangNode?.position.x)!) > 0 {
			aswangNode?.eulerAngles = SCNVector3(0,90,0)
		}
		
		if Float((aswangNode?.position.z)!) == 0.0 && Float((aswangNode?.position.x)!) < 0 {
			aswangNode?.eulerAngles = SCNVector3(0,-90,0)
		}
	}

	
//MARK: HANDLERS########################
	//make tap action..
	@objc func handleTap(sender: UITapGestureRecognizer){ // make an action for tapgstrRecgnzr to do when tapped
		let sceneViewTappedon = sender.view as! SCNView // variable for the sender which is a view
		let touchCoordinates = sender.location(in: sceneViewTappedon)// get coords objectView tapped on
		let hitTest = sceneViewTappedon.hitTest(touchCoordinates) // uses designated coords of the objView tapped on
		if hitTest.isEmpty{ // if no obj cordinates in that space then it is empty
		}else {
			if countdown > 0{ // cant tap out a zombie when timer runs out
				//actions when a model node is tapped..
				let results = hitTest.first! // assign with coords of tapped model node
				let attackedNode =  results.node //make a node var that is for touched model node of that result coord
				if attackedNode.animationKeys.isEmpty{ // so animation is not done in multiples
					
                    
					//make sword...
					let swordScene = SCNScene(named: "sword.scnassets/sword.scn")
					let swordNode = swordScene?.rootNode.childNode(withName: "sword", recursively: false)
                    swordNode?.position = SCNVector3Make(0.18, 3.1, 0.0)
					attackedNode.addChildNode(swordNode!) //make sword a child of the attackedNode so it locates relative to it
					self.playWpnFX(fx: "swoosh")
					
					//ANIMATION & ACTION CHAIN (so the actions dont override animations)..
					SCNTransaction.begin() //start the animation series
					self.swordSwipe(node: swordNode!)												                                                	//!!!!!!!!!
                    
                    if aswangExists == true {
                        
                                                                                                                                       //!!!!!!!!!!!
                        self.nodeShaker(node: attackedNode) // call and use the animateNode func we made
                        self.playRoar(roar: "deathRoar")
                       
                        SCNTransaction.completionBlock = { // safely add another animation
                            attackedNode.removeFromParentNode()// this action makes node disappear
                            
                            self.addAswang() //then put the node back in another random spot
                            self.restoreTimer()
                            self.playMusic(track: "scaryMusic1")
                            self.playSound(sound: "growl1")
                            
                            aswangExists = false
                        }
                        SCNTransaction.commit() // complete the anitmation sequence & runs it
                        
                        kills += 1
                        killsLabel.text = String("Kills: \(kills)")
                    }
                }else{
                    return // if there is a node there already then return nothing.(so overtaping doesnt over come pgm)
                }
			}
		}
	}
		

//MARK: ANIMATIONS########################
	func nodeShaker(node: SCNNode){  // make an animation for the model node when tapped
		let spin = CABasicAnimation(keyPath: "position")// choose position as the aspect to animate
		spin.fromValue = node.presentation.position // start animation in current position
		spin.toValue = SCNVector3(node.presentation.position.x - 0.2,node.presentation.position.y - 0.2,node.presentation.position.z - 0.2)//end animation 0.2mtr further away on  axis
		spin.autoreverses = true // animate back smooothly to original Position
		spin.duration = 0.05 // will take 0.05 secs for each direction
		spin.repeatCount = 5 // repeat the animation 5 times
		node.addAnimation(spin, forKey: "position") // add spin animation to the node
	}

	func swordSwipe(node: SCNNode){																		//!!!!!!!!!
		let swipe =  CABasicAnimation(keyPath: "position")
		swipe.fromValue = node.presentation.position
		swipe.toValue = SCNVector3(node.presentation.position.x - 1.0, node.presentation.position.y - 0, node.presentation.position.z - 0)
		swipe.duration = 0.0001
		node.addAnimation(swipe, forKey: "position")
		
	}

	

	
//MARK: MODEL FUNCTIONS###################
	func restartSession(){
		self.sceneView.session.pause()
		self.sceneView.scene.rootNode.enumerateChildNodes { (node, _) in
			node.removeFromParentNode()
		}
		self.sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
	}
	
	
	func randomNumbers(firstNum: CGFloat, secondNum: CGFloat)-> CGFloat{
		return CGFloat(arc4random())/CGFloat(UINT32_MAX) * abs(firstNum - secondNum) + min(firstNum,secondNum)
	}
	
	
	
	
//MARK: TIMERS########################
	func setTimer(){
		timer.perform { () -> NextStep in
			countdown -= 1
			self.timerLabel.text = String(countdown)
			// timer runs out actions..
			if countdown == 0 {
				self.timerLabel.text = "you lose"
				self.playSound(sound: "loudHorn")
				//self.view.layer?.backgroundColor = Color.blue.cgColor								//!!!!!!!!!!!
				
				return .stop
			}
			return .continue
		}
	}
	
	func restoreTimer(){
		countdown =  10
		self.timerLabel.text = String(countdown)
		playMusic(track: "scaryMusic1")
		
	}
	
	
	func setRoundTimer(){
		roundTimer.perform { () -> NextStep in
			timeLimit -= 1
			
			// timeLimit runs out actions..
			if timeLimit == 0 {
				if kills >= 50 {
				NextLevelAlertVC.showAlert(self, title: "Well Done Hunter!", message: "Go to next level.")
				self.playSound(sound: "policeSiren")
				}else{
					NextLevelAlertVC.showAlert(self, title: "Try Again!", message: "Less than 50 kills")
				}
				
				timer.stop()
				self.restoreTimer()
				self.play.isEnabled = true
				self.sceneView.scene.rootNode.enumerateChildNodes { (node, _) in
					node.removeFromParentNode()
				}
				
				timeLimit = 10
				
				return .stop
			}
			return .continue
		}
	}
	
	
	
	
//MARK: AUDIO FUNCTIONS ########################

    func playMusic(track: String){
            let path = Bundle.main.path(forResource: "\(track)", ofType: "mp3")!
            let url = URL(fileURLWithPath: path)
            do{
               // return
                musicPlayer = try AVAudioPlayer(contentsOf: url)
                musicPlayer?.play()
            } catch{
                print(error)
            }
        }
    
    
    func playSound(sound: String){
		let path = Bundle.main.path(forResource: "\(sound)", ofType: "mp3")!
		let url = URL(fileURLWithPath: path)
		do{
            
			soundPlayer = try AVAudioPlayer(contentsOf: url)
			soundPlayer?.play()
		} catch{
			print(error)
		}
	}
	
	
	
	func playWpnFX(fx: String){
		let path = Bundle.main.path(forResource: "\(fx)", ofType: "mp3")!
		let url = URL(fileURLWithPath: path)
		do{
			
            weaponPlayer = try AVAudioPlayer(contentsOf: url)
			weaponPlayer?.play()
		} catch{
			print(error)
		}
	}
	
	func playRoar(roar: String){
		let path = Bundle.main.path(forResource: "\(roar)", ofType: "mp3")!
		let url = URL(fileURLWithPath: path)
		do{
			
            roarPlayer = try AVAudioPlayer(contentsOf: url)
			roarPlayer?.play()
		} catch{
			print(error)
		}
	}
	
	
	
/*
	func randomPosition(aswangNode: SCNScene?, named:  , withname:){
		// random positioning of model node..
		aswangNode.position = SCNVector3Make(Float(randomNumbers(firstNum: -3, secondNum: 3)), Float(randomNumbers(firstNum: -2, secondNum: -2)), Float(randomNumbers(firstNum: -3, secondNum: 3)))
		self.sceneView.scene.rootNode.addChildNode(aswangNode!)
		
		if Float((aswangNode?.position.z)!) > 0.0 {
			aswangNode?.eulerAngles = SCNVector3(0,180,0)
		}
		
		if Float((aswangNode?.position.z)!) == 0.0 && Float((aswangNode?.position.x)!) > 0 {
			aswangNode?.eulerAngles = SCNVector3(0,90,0)
		}
		
		if Float((aswangNode?.position.z)!) == 0.0 && Float((aswangNode?.position.x)!) < 0 {
			aswangNode?.eulerAngles = SCNVector3(0,-90,0)
		}
	}
*/
    
}

//m
func + (left: SCNVector3, right: SCNVector3)-> SCNVector3{// ext on the + operator for the
    return SCNVector3Make(left.x + right.x, left.y + right.y, left.z + right.z)
    
}








